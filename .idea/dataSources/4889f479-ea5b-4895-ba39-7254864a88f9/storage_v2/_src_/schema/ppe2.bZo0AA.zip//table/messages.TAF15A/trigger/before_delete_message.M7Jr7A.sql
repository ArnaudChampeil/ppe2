create definer = root@localhost trigger before_delete_message
  before DELETE
  on messages
  for each row
BEGIN
INSERT INTO historisation(id_message, content, dateCreation, id_account, id_channel) 
VALUES (messages.id_message, messages.content, messages.dateCreation, messages.id_account, messages.id_channel);
END;

