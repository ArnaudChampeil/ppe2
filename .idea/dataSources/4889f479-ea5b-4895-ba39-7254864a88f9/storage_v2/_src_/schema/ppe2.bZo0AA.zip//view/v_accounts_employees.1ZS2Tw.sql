create view v_accounts_employees as
select `a`.`id_account` AS `id_account`,
       `a`.`name`       AS `name`,
       `a`.`firstname`  AS `firstname`,
       `a`.`email`      AS `email`,
       `a`.`password`   AS `password`,
       `a`.`nbMessages` AS `nbMessages`,
       `e`.`post`       AS `post`,
       `e`.`access`     AS `access`
from (`ppe2`.`accounts` `a`
       join `ppe2`.`employees` `e` on ((`a`.`id_account` = `e`.`id_account`)));

